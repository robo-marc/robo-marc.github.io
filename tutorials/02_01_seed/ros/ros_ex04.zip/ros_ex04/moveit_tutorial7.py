#!/usr/bin/env python
#-*- coding: utf-8 -*-

import rospy
import math
import copy
import moveit_commander
import moveit_msgs.msg
from geometry_msgs.msg import Quaternion, Pose, PoseStamped, Vector3
from tf.transformations import quaternion_from_euler

#################################################
#Global Function
#################################################
SLEEP_TIME = 1.5

def euler_to_quaternion(role, pitch, yaw):
  q = quaternion_from_euler(role, pitch, yaw)
  return Quaternion(q[0], q[1], q[2], q[3])

#################################################
#Main Part
#################################################
def main():
  #Initialization of Node
  rospy.init_node("moveit_tutorial_node")

  #Configuration for MoveIt!
  robot = moveit_commander.RobotCommander()
  scene = moveit_commander.PlanningSceneInterface()

  #Display of Group Name
  print "Robot Groups:", robot.get_group_names()
  print "Robot State:", robot.get_current_state()

  #Store the objects of each group name
  rarm = moveit_commander.MoveGroupCommander("rarm")
  larm = moveit_commander.MoveGroupCommander("larm")
  upper_body = moveit_commander.MoveGroupCommander("upper_body")
  rarm_with_waist = moveit_commander.MoveGroupCommander("rarm_with_waist")

  #Set Pose to Home Position
  joint_goal = upper_body.get_current_joint_values()
  for i in range(0, len(joint_goal)):
    joint_goal[i] = 0
  joint_goal[6] = -3
  joint_goal[16] = -3
  upper_body.go(joint_goal, wait=True)

  #ここから演習４以降のコードを追加してください。
  #右腕と腰の全体での目標位置・姿勢へ動かす
  rarm_with_waist.set_end_effector_link("r_eef_pick_link")
  pose_goal = Pose()
  pose_goal.orientation = euler_to_quaternion(-1.57, 0, 0)
  pose_goal.position.x = 0.8
  pose_goal.position.y = -0.2
  pose_goal.position.z = 1.2
  rarm_with_waist.set_pose_target(pose_goal)
  rarm_with_waist.go(wait = True)
  rospy.sleep(SLEEP_TIME*3)

  #RViz上に箱を表示
  box_name = "box"
  box_pose = PoseStamped()
  box_pose.header.frame_id = "r_eef_pick_link"
  box_pose.pose.orientation = euler_to_quaternion(0,0,0)
  scene.add_box(box_name, box_pose, size=(0.03, 0.03, 0.03))
  rospy.sleep(SLEEP_TIME)

  #箱を手先と関連付ける
  grasping_group = 'rarm_with_waist'
  touch_links = robot.get_link_names(group=grasping_group)
  eef_link = rarm_with_waist.get_end_effector_link()
  scene.attach_box(eef_link, box_name, touch_links=touch_links)
  rospy.sleep(SLEEP_TIME)
  

  #右手と腰の全体を用いて、物体を移動する
  pose_goal.orientation = euler_to_quaternion(-1.57, 0, 0)
  pose_goal.position.x = 0.4
  pose_goal.position.y = -0.2
  pose_goal.position.z = 1.2
  rarm_with_waist.set_pose_target(pose_goal)
  rarm_with_waist.go(wait = True)
  
  #箱を置く
  scene.remove_attached_object(eef_link, name=box_name)
  rospy.sleep(SLEEP_TIME)

  #初期位置に戻る
  joint_goal = upper_body.get_current_joint_values()
  for i in range(0, len(joint_goal)):
    joint_goal[i] = 0
  joint_goal[6] = -3
  joint_goal[16] = -3
  upper_body.go(joint_goal, wait=True)

  #箱を消す
  scene.remove_world_object(box_name)

  #ここまで


if __name__ == '__main__':
  try:
    main()
  except rospy.ROSInterruptException:
    pass
