#!/usr/bin/env python
#-*- coding: utf-8 -*-

import rospy
import math
import copy
import moveit_commander
import moveit_msgs.msg
from geometry_msgs.msg import Quaternion, Pose, PoseStamped, Vector3

#################################################
#Main Part
#################################################
def main():
  #Initialization of Node
  rospy.init_node("moveit_tutorial_node")

  #Configuration for MoveIt!
  robot = moveit_commander.RobotCommander()
  #Display of Group Name
  print "Robot Groups:", robot.get_group_names()
  print "Robot State:", robot.get_current_state()

  #Store the objects of each group name
  rarm = moveit_commander.MoveGroupCommander("rarm")
  larm = moveit_commander.MoveGroupCommander("larm")
  upper_body = moveit_commander.MoveGroupCommander("upper_body")
  rarm_with_waist = moveit_commander.MoveGroupCommander("rarm_with_waist")

  #Set Pose to Home Position
  joint_goal = upper_body.get_current_joint_values()
  for i in range(0, len(joint_goal)):
    joint_goal[i] = 0
  joint_goal[6] = -3
  joint_goal[16] = -3
  upper_body.go(joint_goal, wait=True)

  #ここから演習４以降のコードを追加してください。
  #左腕の指令値の生成
  larm.set_end_effector_link("l_eef_pick_link")
  joint_goal = larm.get_current_joint_values()
  #左腕の肘を90度に設定
  joint_goal[3] = -1.57
  print "Left Arm:", larm.go(joint_goal, wait = True )

  #右腕と腰を一緒に動かすための指令値を生成
  joint_goal = rarm_with_waist.get_current_joint_values()
  #腰を回転させる
  joint_goal[0] = 1.0
  #右の肘を動かす
  joint_goal[6] = -1.0
  print"Right Arm with Waist:", rarm_with_waist.go(joint_goal, wait = True)

  #上半身の制御を行うための指令値を生成
  joint_goal = upper_body.get_current_joint_values()
  #腰を回転させる
  joint_goal[0] = 0
  #両腕の制御
  joint_goal[6] = -2.3
  joint_goal[16] = -2.3
  print"Upper Body:", upper_body.go(joint_goal, wait = True)
  #ここまで

if __name__ == '__main__':
  try:
    main()
  except rospy.ROSInterruptException:
    pass
