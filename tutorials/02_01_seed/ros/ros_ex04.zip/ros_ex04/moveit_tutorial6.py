#!/usr/bin/env python
#-*- coding: utf-8 -*-

import rospy
import math
import copy
import moveit_commander
import moveit_msgs.msg
from geometry_msgs.msg import Quaternion, Pose, PoseStamped, Vector3
from tf.transformations import quaternion_from_euler
from seed_r7_ros_controller.srv import *

#################################################
#Global Function
#################################################
SLEEP_TIME = 1.5

def euler_to_quaternion(role, pitch, yaw):
  q = quaternion_from_euler(role, pitch, yaw)
  return Quaternion(q[0], q[1], q[2], q[3])

#################################################
#Main Part
#################################################
def main():
  #Initialization of Node
  rospy.init_node("moveit_tutorial_node")

  #Configuration for MoveIt!
  robot = moveit_commander.RobotCommander()
  scene = moveit_commander.PlanningSceneInterface()
  #Display of Group Name
  print "Robot Groups:", robot.get_group_names()
  print "Robot State:", robot.get_current_state()

  #Store the objects of each group name
  rarm = moveit_commander.MoveGroupCommander("rarm")
  larm = moveit_commander.MoveGroupCommander("larm")
  upper_body = moveit_commander.MoveGroupCommander("upper_body")
  rarm_with_waist = moveit_commander.MoveGroupCommander("rarm_with_waist")

  #Set Pose to Home Position
  joint_goal = upper_body.get_current_joint_values()
  for i in range(0, len(joint_goal)):
    joint_goal[i] = 0
  joint_goal[6] = -3
  joint_goal[16] = -3
  upper_body.go(joint_goal, wait=True)

  #ここから演習４以降のコードを追加してください。
  #右腕と腰の全体での目標位置・姿勢へ動かす
  rarm_with_waist.set_end_effector_link("r_eef_pick_link")
  pose_goal = Pose()
  pose_goal.orientation.w = 1.0
  pose_goal.position.x = 0.8
  pose_goal.position.y = -0.2
  pose_goal.position.z = 1.2
  rarm_with_waist.set_pose_target(pose_goal)
  rarm_with_waist.go(wait = True)

  #手先の直線軌道での制御
  waypoints = []
  wpose = rarm_with_waist.get_current_pose().pose
  wpose.position.z +=-1*0.1
  waypoints.append(copy.deepcopy(wpose))
  wpose.position.y += 1*0.1
  waypoints.append(copy.deepcopy(wpose))
  wpose.position.z += 1*0.1
  waypoints.append(copy.deepcopy(wpose))
  wpose.position.y +=-1*0.1
  waypoints.append(copy.deepcopy(wpose))

  (plan, fraction) = rarm_with_waist.compute_cartesian_path(waypoints, 0.01, 0.0)
  print "CARTESIAN", rarm_with_waist.execute(plan, wait=True)
  #ここまで


if __name__ == '__main__':
  try:
    main()
  except rospy.ROSInterruptException:
    pass
