#!/usr/bin/env python
#-*- coding: utf-8 -*-

import rospy
import math
import copy
import moveit_commander
import moveit_msgs.msg
from geometry_msgs.msg import Quaternion, Pose, PoseStamped, Vector3

#################################################
#Main Part
#################################################
def main():
  #Initialization of Node
  rospy.init_node("moveit_tutorial_node")

  #Configuration for MoveIt!
  robot = moveit_commander.RobotCommander()
  #Display of Group Name
  print "Robot Groups:", robot.get_group_names()
  print "Robot State:", robot.get_current_state()

  #Store the objects of each group name
  rarm = moveit_commander.MoveGroupCommander("rarm")
  larm = moveit_commander.MoveGroupCommander("larm")
  upper_body = moveit_commander.MoveGroupCommander("upper_body")
  rarm_with_waist = moveit_commander.MoveGroupCommander("rarm_with_waist")

  #Display of Joint Name
  print ""
  print "Right Arm Group Joint Names:", robot.get_joint_names("rarm")
  print ""
  print "Left Arm Group Joint Names:", robot.get_joint_names("larm")
  print ""
  print "Upper Body Group Joint Names:", robot.get_joint_names("upper_body")
  print ""
  print "Right Arm with Waist Group Joint Names:", robot.get_joint_names("rarm_with_waist")

if __name__ == '__main__':
  try:
    main()
  except rospy.ROSInterruptException:
    pass
