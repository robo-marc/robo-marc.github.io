#!/usr/bin/env python
#-*- coding: utf-8 -*-

import rospy

#################################################
#Main Part
#################################################
def main():
  #Initialization of Node
  rospy.init_node("moveit_tutorial_node")
  
  print("MoveIt! tutorial node is created!!")

if __name__ == '__main__':
  try:
    main()
  except rospy.ROSInterruptException:
    pass
